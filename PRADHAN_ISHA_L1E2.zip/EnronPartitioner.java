package Enron;

import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class EnronPartitioner<Text, IntWritable> extends Partitioner<Text, IntWritable> {
	private int m=22;
	private int firstLetterValue=0;
	String temp="";

	public int getPartition(Text key, IntWritable value, int numReduceTasks) {
		temp=key.toString();
		firstLetterValue=temp.charAt(0);
		
		
		if(numReduceTasks == 0)
                return 0;

		else if(numReduceTasks == 1)
                return 0;

		
		if(numReduceTasks ==2)
		{
			if(firstLetterValue<=109)
			return 0;
		
			else 
			return 1;
		}

		else
		return -1;



	}
}

